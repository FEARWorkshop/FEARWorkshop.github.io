// writes 0 in each cell of the
// array a of len integers
void reset_array(int* a, int len){
  for(int i = 0 ; i < len ; ++i){
    a[i] = 0 ;
  }
}
