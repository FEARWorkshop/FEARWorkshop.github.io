// increment *a by the value of *b, and leaves b unchanged
void incr_a_by_b(int* a, int* b){
  *a += *b;
}
